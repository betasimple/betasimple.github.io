<?php
return array(
    // 应用版本
    'app_version' => '2.1.1',
    
    // 发布时间
    'release_time' => '20200706',
    
    // 修订版本
    'revise_version' => '0'

);
