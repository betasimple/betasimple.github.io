<!DOCTYPE html>
<html>
<head>
<!--[if lt IE 9]>
<script type="text/javascript" src="static/js/html5.js"></script>
<![endif]-->
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge, chrome=1">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<meta name="format-detection" content="telephone=no" />
<title>{pboot:pagetitle}</title>
<meta name="keywords" content="{pboot:pagekeywords}">
<meta name="description" content="{pboot:pagedescription}">
<meta name="author" content="www.niumacms.com"/>
<script type="text/javascript" src="{pboot:sitepath}/pc/js/jquery.min.js"></script>
<link rel="stylesheet" type="text/css" href="{pboot:sitepath}/pc/css/animate.min.css">
<link rel="stylesheet" type="text/css" href="{pboot:sitepath}/pc/css/owl.carousel.min.css">
<link rel="stylesheet" type="text/css" href="{pboot:sitepath}/pc/css/global.css">
<link rel="stylesheet" type="text/css" href="{pboot:sitepath}/pc/css/style.css">
<script type="text/javascript" src="{pboot:sitepath}/pc/js/owl.carousel.js"></script>
<script type="text/javascript" src="{pboot:sitepath}/pc/js/wow.js"></script>
<script type="text/javascript" src="{pboot:sitepath}/pc/js/main.js"></script>
</head>
<body>
<!-------------------------------------- 头部开始 --------------------------------------> 
<div class="header">
  <div class="logo flt"><a href="{pboot:sitepath}/"><img src="{pboot:sitelogo}"/></a></div>
  <div class="h_icon flt"><span class="qq">{pboot:companyqq}</span></div>
  <div class="h_icon flt"><span class="tel">{pboot:companymobile}</span></div>
  <div class="h_text frt">导航</div>
  <div class="menu_btn frt">
    <label class="lbl1"></label>
    <label class="lbl2"></label>
    <label class="lbl3"></label>
  </div>
  <div class="menu frt">
    <ul>
      <li {pboot:if(0=='{sort:scode}')}class="on"{/pboot:if}><a href="{pboot:sitepath}/">
        <h4 class="icon0">网站首页<span>home page</span></h4>
        </a></li>
      {pboot:nav}
      <li {pboot:if('[nav:scode]'=='{sort:tcode}')}class="on"{/pboot:if} ><a href="[nav:link]">
        <h4 class="icon[nav:i]">[nav:name]<span>[nav:subname]</span></h4>
        </a> </li>
      {/pboot:nav}
    </ul>
  </div>
  <div class="menu_wrap"></div>
  <div class="clear"></div>
</div>
 
<!-------------------------------------- 头部结束 --------------------------------------> 
<!-------------------------------------- 内容开始 -------------------------------------->
<div class="mainer">
  <div class="banner"> {pboot:slide gid=1}
    <div class="item">
      <div class="img1"><img src="[slide:src]"/></div>
      <div class="text">
        <div class="wrap">
          <h2 class="wow fadeInUp" data-wow-delay=".1s">[slide:title]</h2>
          <p class="wow fadeInUp" data-wow-delay=".2s">[slide:subtitle]</p>
          <p class="wow fadeInUp" data-wow-delay=".3s"></p>
        </div>
      </div>
    </div>
    {/pboot:slide} </div>
  <div class="page_list">
    <div class="page page1">
      <div class="wrap">
        <div class="page1_text clear wow fadeInUp" data-wow-delay=".1s">
          <div class="img_box">
            <div class="img_bg"><img src="{pboot:sitepath}/pc/images/bg.png"/></div>
            <div class="img"><img src="{pboot:sitepath}/pc/images/img1.jpg"/></div>
          </div>
          {pboot:content id=1}
          <div class="text">
            <h3>[content:title]</h3>
            <label class="line"></label>
            <p> [content:content drophtml=1 dropblank=1 len=300 more='']</p>
            <div class="btn"><a href="[content:link]">查看更多</a></div>
          </div>
          {/pboot:content} </div>
      </div>
    </div>
    <div class="page page2">
      <div class="wrap">
        <div class="page2_text clear wow fadeInUp" data-wow-delay=".1s"> {pboot:sort scode=4}
          <div class="img_box">
            <div class="text1"><span>[sort:name]</span></div>
            <div class="img"><img src="{pboot:sitepath}/pc/images/img2.jpg" /></div>
          </div>
          <div class="text over">
            <h3>[sort:name]</h3>
            <p>[sort:description]</p>
          </div>
          {/pboot:sort} </div>
        <div class="page2_owl">
          <div class="owl_cur wow fadeInUp" data-wow-delay=".1s"> <span class="prev">P R E V</span> <span class="next">N E X T</span> </div>
          <div class="owl wow fadeInUp" data-wow-delay=".1s"> {pboot:list scode=4 num=5 order=sorting}
            <div class="item">
              <div class="box">
                <div class="img1"><img src="{pboot:sitepath}/pc/images/yewu[list:i].png" /></div>
                <h3>[list:title]</h3>
                <p>[list:subtitle]</p>
              </div>
            </div>
            {/pboot:list} </div>
        </div>
      </div>
    </div>
    <div class="page page3">
      <div class="wrap clear">
        <div class="page3_text wow fadeInUp" data-wow-delay=".1s"> {pboot:sort scode=3}
          <h3>[sort:name]</h3>
          {/pboot:sort}
          <label class="line"></label>
          <div class="list">
            <ul class="clear ul_tag">
              {pboot:nav parent=3}
              <li {pboot:if('[nav:scode]'=='{sort:scode}')} class="on"   {/pboot:if}> <a href="[nav:link]">[nav:name]</a> </li>
              {/pboot:nav}
            </ul>
          </div>
          {pboot:list scode=3 num=1 order=sorting}
          <div class="text">
            <h4>[list:title]</h4>
            <p>产品简介：[list:content drophtml=1 len=200]</p>
            <div class="btn"><a href="[list:link]">查看更多</a></div>
          </div>
          {/pboot:list} </div>
        <div class="page3_list wow fadeInUp" data-wow-delay=".2s">
          <div class="list">
            <ul>
              {pboot:list scode=3 num=6 order=date}
              <li><a href="[list:link]">
                <div class="img"><img src="[list:ico]"></div>
                <div class="text"><span>[list:title]</span></div>
                </a></li>
              {/pboot:list}
            </ul>
          </div>
        </div>
      </div>
    </div>
    <div class="page page4">
      <div class="wrap">
        <div class="page_tit wow fadeInUp" data-wow-delay=".1s"> {pboot:sort scode=8}
          <h3>[sort:name]</h3>
          {/pboot:sort}
          <label class="line"></label>
        </div>
        <div class="team_owl">
          <div class="team_text wow fadeInUp" data-wow-delay=".1s">
            <div class="owl_cur"> <span class="prev">P R E V</span> <span class="next">N E X T</span> </div>
            {pboot:sort scode=8}
            <div class="text">
              <p>[sort:description]</p>
            </div>
            {/pboot:sort} </div>
          <div class="owl wow fadeInUp" data-wow-delay=".1s"> {pboot:list scode=8 num=9 order=date}
            <div class="item"> <a href="[list:link]">
              <div class="img"><img src="[list:ico]"/></div>
              </a>
              <div class="text">
                <h3>[list:title]</h3>
                <p>[list:ext_zhicheng]</p>
              </div>
            </div>
            {/pboot:list} </div>
        </div>
      </div>
    </div>
    <div class="page page5">
      <div class="wrap">
        <div class="page_tit wow fadeInUp" data-wow-delay=".1s"> {pboot:sort scode=2}
          <h3>[sort:name]</h3>
          {/pboot:sort}
          <label class="line"></label>
        </div>
        <div class="news_owl owl_carousel wow fadeInUp" data-wow-delay=".1s">
          <div class="owl_cur"> <span class="prev">P R E V</span> <span class="next">N E X T</span> </div>
          <div class="owl"> {pboot:list scode=2 num=6 order=date}
            <div class="item"> <a href="[list:link]">
              <div class="img"><img src="[list:ico]"/></div>
              <div class="text">
                <h3>[list:title]</h3>
                <p>[list:content drophtml=1 len=100]</p>
                <div class="bottom"> <span>[list:date style=Y-m-d]</span>
                  <div class="btn"><span>详情</span></div>
                </div>
              </div>
              </a> </div>
            {/pboot:list} </div>
        </div>
      </div>
    </div>
    <div class="page page6">
      <div class="wrap clear">
        <div class="page6_text wow fadeInUp" data-wow-delay=".1s">
          <div class="page_tit left">
            <h3>联系我们</h3>
            <label class="line"></label>
          </div>
          {pboot:sort scode=7}
          <div class="text">
            <p>[sort:description]</p>
          </div>
          {/pboot:sort}
          <div class="list">
            <ul>
              <li class="li1">
                <p>地址： {pboot:companyaddress}</p>
              </li>
              <li class="li2">
                <p>电话： {pboot:companyphone}</p>
              </li>
              <li class="li3">
                <p>邮箱： {pboot:companyemail}</p>
              </li>
            </ul>
          </div>
          <div class="ewm"> <i class="i_t i_l"></i> <i class="i_l i_b"></i> <i class="i_b i_r"></i> <i class="i_t i_r"></i> <img src="{pboot:companyweixin}" /></div>
        </div>
        <form action="{pboot:msgaction}" method="post">
          <div class="page6_contact wow fadeInUp" data-wow-delay=".1s">
            <h3>在线留言</h3>
            <div class="list">
              <ul>
                <li><span>您的称呼</span>
                  <div class="div_input">
                    <input type="text" name='contacts' id='name' placeholder="您的称呼"/>
                  </div>
                </li>
                <li><span>您的电话</span>
                  <div class="div_input">
                    <input type="text" name='mobile' id='tel' placeholder="您的电话"/>
                  </div>
                </li>
                <li class="li_last"><span>需求和建议</span>
                  <div class="div_input">
                    <textarea name='content' placeholder="写下您的需求和建议"></textarea>
                  </div>
                </li>
              </ul>
            </div>
            <div class="clear"></div>
            <div class="btn center"><a onclick="$('form').submit()">提交</a></div>
          </div>
        </form>
      </div>
    </div>
  </div>
   <div class="copyright">
  <p>{pboot:sitecopyright} 网站备案号：<a style="color:#fff;" href="https://beian.miit.gov.cn/">{pboot:siteicp}</a></p>
</div> </div>
<div class="full">
  <ul>
    <li><a href="https://wpa.qq.com/msgrd?v=3&uin={pboot:companyqq}&site=qq&menu=yes">
	<span class="span1"></span>
      <label>在线QQ</label>
      </a></li>
    <li><a href="javascript:void(0)"><span class="span2"></span>
      <label>{pboot:companyphone}</label>
      </a></li>
    <li><a href="javascript:void(0)"><span class="span3"></span>
      <label class="lbl_img"><img src="{pboot:companyweixin}"></label>
      </a></li>
    <li><a href="javascript:void(0)" class="gotop" onclick="$('html,body').stop().animate({scrollTop:0},800)">
	<span class="span4"></span></a>
	</li>
  </ul>
</div> 
<script type="text/javascript"  src="{pboot:sitepath}/pc/js/su_new.js"></script>
</body>
</html><?php return array (
  0 => 'D:/phpStudy/PHPTutorial/WWW/template/niumacms/comm/top.html',
  1 => 'D:/phpStudy/PHPTutorial/WWW/template/niumacms/comm/foot.html',
  2 => 'D:/phpStudy/PHPTutorial/WWW/template/niumacms/comm/kf.html',
); ?>